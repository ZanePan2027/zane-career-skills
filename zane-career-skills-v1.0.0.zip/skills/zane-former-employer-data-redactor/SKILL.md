---
name: zane-former-employer-data-redactor
description: 审查职业作品集、简历、知识库与面试材料中的前雇主数据，按公开性、敏感性、必要性和可替代表达判断保留、模糊化、移至面试口述或删除。Use before publishing employer metrics, profit, margin, cost, customer, campaign, conversion, salary, internal screenshots, operational dashboards, or any non-public business information.
metadata:
  version: "1.0.0"
---

# Former Employer Data Redactor

默认目标是保护前雇主与候选人信誉，同时保留足以证明能力的公开证据。

先做输入准入：包含患者／受试者、客户个人身份、证件、访问凭据、私聊、未脱敏合同或第三方高度敏感信息的原件，若不影响当前招聘判断，不读取、不复制、不送入公开工作区；只登记材料类型与排除原因，并请求脱敏摘要。脱敏不是“先读完再删”的默认许可。

若用户要完整建设作品集，由 `zane-career-portfolio-builder` 统一管理网站、知识库、Word、图表和生成源；本Skill的删除决定必须写入共享决策账本，并同步到所有载体、生成源与rejected_claims，防止旧版本再次恢复。

## 四项判断

对每项数据判断：

1. 公开性：是否已由企业、平台或权威公开渠道披露？
2. 敏感性：是否暴露利润、毛利、成本、客户、合同、内部效率、未发布战略或个人信息？
3. 招聘必要性：删除后是否仍能证明候选人的判断与责任？
4. 可替代性：能否用区间、比例、趋势、数量级或定性结果替代？

## 处理等级

| 处理 | 适用情况 |
|---|---|
| 保留 | 已公开、本人职责明确、对招聘判断必要 |
| 模糊化 | 有证明价值但精确值敏感；改区间、数量级、比例或趋势 |
| 移至面试 | 不适合公开，但可在合规前提下口述判断过程 |
| 删除 | 利润/毛利等核心经营隐私、来源不明、无法证明、收益低于风险 |

## 高风险项

优先审查：订单毛利、净利率、采购/投放底价、客户名单与合同、内部后台截图、账号密码/链接权限、个人手机号、离职后内部结果、未公开组织和战略调整。

## 输出

逐项给出：位置、原文/准确描述、风险机制、保留/模糊/删除建议、替代表达、招聘收益与代价。不要擅自把敏感数字搬到其他载体；所有生成源和公开副本必须同步清理。

来源说明见 [references/method-origin.md](references/method-origin.md)。
